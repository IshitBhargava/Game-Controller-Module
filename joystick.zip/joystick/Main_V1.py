import serial
import pyautogui

# Open serial connection to Arduino Uno
ser = serial.Serial('COM4', 2000000)  # Replace 'COM4' with your Arduino's port
pyautogui.FAILSAFE = False

# Set the duration for mouse movements (in seconds)
move_duration = 0.0001  # Adjust as needed

# Initialize the state of button 2
prev_buttonState2 = 1  # Assuming button is initially not pressed

while True:
    # Read data from serial
    data = ser.readline().decode().strip().split(',')
    if len(data) == 5:
        try:
            xAxisValue, yAxisValue, buttonState1, buttonState2, potValue = map(int, data)
        except ValueError:
            continue
        
        # Move mouse cursor
        if xAxisValue != 512 or yAxisValue != 524:
            mouseX = pyautogui.position()[0] - (xAxisValue - 512) / 100  # Invert direction
            mouseY = pyautogui.position()[1] + (yAxisValue - 524) / 100
            pyautogui.moveTo(mouseX, mouseY, duration=move_duration)
        
        # Check button states and perform actions
        if buttonState1 == 0:  # Button 1 pressed
            pyautogui.press('down')
            print("Button 1 pressed- dwon")

        if buttonState2 == 0 and prev_buttonState2 == 1:  # Button 2 pressed (and was not pressed before)
            pyautogui.press('space')  # Press spacebar
            print("Spacebar pressed")

        # Update the previous state of button 2
        prev_buttonState2 = buttonState2
        
        # Simulate keyboard key presses based on potentiometer value
        if potValue < 341:
            pyautogui.press('left')    # Press left arrow key
            print("left")
        elif 341 <= potValue <= 682:
            pyautogui.press('up')      # Press up arrow key
            print("up")
        elif potValue > 682:
            pyautogui.press('right')   # Press right arrow key
            print("right")
