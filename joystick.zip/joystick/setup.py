from setuptools import setup, find_packages

setup(
    name='pong',
    version='1.0',
    packages=find_packages(),
    install_requires=['pydirectinput', 'serial'],
    author='Ishit Bhargava',
    author_email='ishit.bh@gmail.com',
    description='A arduino and python project for playing geoFS',
    url='https://github.com/ishitbhargava/',
)
s